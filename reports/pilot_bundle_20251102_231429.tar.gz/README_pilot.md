# Pilot Review Checklist

## Decision
- GO series: none
- NO-GO series: CPI
- Global reasons: none
- Final decision: NO-GO
- Decision rationale: NO-GO series: CPI

## Session Snapshot
- Session ID: pilot-cpi-20251102T231404Z-158ec2
- Started at: 2025-11-02T23:14:04.146766+00:00
- Trades: 2
- Mean Δbps after fees: -4718.3
- CuSum status: NO_DATA
- Fill realism gap: n/a
- Alerts: none

## Checklist
- EV honesty: clean
- Sequential guard (CuSum): NO_DATA
- Freeze violations: none
- Drawdown: OK
- WS health: n/a; Auth health: n/a
- Ledger staleness: 3.220 min (limit 120.0) — OK
- Monitor staleness: 2.110 min (limit 30.0) — OK
