# Pilot Ramp Readiness

_Generated 2025-11-02T23:14:26.795947+00:00_

**Criteria**
- Min fills: 300
- Min Δbps: 6.0
- Min t-stat: 2.0
- Drawdown caps (daily/weekly): 2000.0/6000.0

**Freshness**
- Ledger age: 3.2 min (limit 120)
- Monitors age: 2.1 min (limit 30)

**Freeze Windows**
- CPI: clear (freeze starts 2025-11-11T06:00:00-05:00)

| Series | Fills | Δbps | t-stat | Guardrail breaches | Drawdown | Recommendation | Multiplier |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CPI | 0 | -4718.34 | -16.75 | 0 | OK | NO_GO | 1.00 |
    - EV honesty bins:
        | Strike | Side | Δbps | Weight | Cap | Sources | Flagged |
        | --- | --- | --- | --- | --- | --- | --- |
        | 0.2 | YES | 0 | n/a | n/a | auto | no |
        | 0.5 | NO | 0 | n/a | n/a | auto | no |
