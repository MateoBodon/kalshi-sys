# Pilot Review Checklist

## Decision
- GO series: none
- NO-GO series: CPI
- Global reasons: monitors_stale
- Final decision: NO-GO
- Decision rationale: NO-GO series: CPI; Global reasons: monitors_stale

## Session Snapshot
- Session ID: pilot-cpi-20251103T001334Z-f3253a
- Started at: 2025-11-03T00:13:34.960549+00:00
- Trades: 2
- Mean Δbps after fees: -4718.3
- CuSum status: NO_DATA
- Fill realism gap: n/a
- Alerts: none

## Checklist
- EV honesty: clean
- Sequential guard (CuSum): NO_DATA
- Freeze violations: none
- Drawdown: OK
- WS health: n/a; Auth health: n/a
- Ledger staleness: 62.6 min (limit 120.0) — OK
- Monitor staleness: 61.5 min (limit 30.0) — STALE
