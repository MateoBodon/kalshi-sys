# Pilot Review Checklist

## Decision
- GO series: none
- NO-GO series: none
- Global reasons: ledger_missing, monitors_missing
- Final decision: NO-GO
- Decision rationale: Global reasons: ledger_missing, monitors_missing

## Session Snapshot
- Session ID: pilot-cpi-20251102T230333Z-2dba67
- Started at: 2025-11-02T23:03:33.850988+00:00
- Trades: 2
- Mean Δbps after fees: -4718.3
- CuSum status: n/a
- Fill realism gap: n/a
- Alerts: none

## Checklist
- EV honesty: clean
- Sequential guard (CuSum): n/a
- Freeze violations: none
- Drawdown: OK
- WS health: n/a; Auth health: n/a
- Ledger staleness: n/a min (limit 120.0) — OK
- Monitor staleness: n/a min (limit 30.0) — OK
