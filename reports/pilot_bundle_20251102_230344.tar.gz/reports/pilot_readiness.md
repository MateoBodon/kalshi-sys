# Pilot Ramp Readiness

_Generated 2025-11-02T23:03:41.412391+00:00_

**Criteria**
- Min fills: 300
- Min Δbps: 6.0
- Min t-stat: 2.0
- Drawdown caps (daily/weekly): 2000.0/6000.0

**Global NO-GO reasons:** ledger_missing, monitors_missing

**Freshness**
- Ledger age: n/a min (limit 120)
- Monitors age: n/a min (limit 30)

| Series | Fills | Δbps | t-stat | Guardrail breaches | Drawdown | Recommendation | Multiplier |
| --- | --- | --- | --- | --- | --- | --- | --- |
